from flask import Flask, request, render_template,send_from_directory, make_response,redirect
from Archives import Archives
import pickle,base64,os
from jinja2 import Environment
from random import choice
import numpy
import builtins
import io
import re
import shelve
from datetime import datetime
YRpxSAtoUsibvJYSNLIvYolgwUhZrDuu = 'guestbook.dat'
app = Flask(__name__)
xNBDtkLZDLeJdmLDjVGzuwsZtSakcPrb = Environment()
def fGvJjqhhlDZwxjaOwhkjDPwybGqGCuPO(type,str):
    lXKGklgbUoAEcAamQHRaTQumElxjTikM = "%s'%s'"%(type,str)
    print(lXKGklgbUoAEcAamQHRaTQumElxjTikM)
    return eval(lXKGklgbUoAEcAamQHRaTQumElxjTikM)
def cwPvcZjBhEWaVhLRfzZbwgpDWBuuDfWn():
    XOEQzutgbKvbuPWaJyfXTVCsoYcidwvR = ['class','+','getitem','request','args','subclasses','builtins']
    return choice(XOEQzutgbKvbuPWaJyfXTVCsoYcidwvR)
@app.route('/')
def index():
    global Archives
    mKoIjtaJXbQWuvPTIyRJdQAjhuCCrKZF = make_response(render_template('index.html', Archives = Archives))
    rOziJaxndtrMPokMGsHkeiErrIZkSief = bytes(cwPvcZjBhEWaVhLRfzZbwgpDWBuuDfWn(), encoding = "utf-8")
    IIGXwOObBDgaVHOgKthObhluszUJGfhE = base64.b64encode(rOziJaxndtrMPokMGsHkeiErrIZkSief)
    mKoIjtaJXbQWuvPTIyRJdQAjhuCCrKZF.set_cookie("username", value=IIGXwOObBDgaVHOgKthObhluszUJGfhE)
    return mKoIjtaJXbQWuvPTIyRJdQAjhuCCrKZF
@app.route('/Archive/<int:id>')
def Archive(id):
    global Archives
    if id>len(Archives):
        return render_template('message.html', GnhtpzUMRZloJKxoggvYzVPFZegJOBQo='文章ID不存在！', status='失败')
    return render_template('Archive.html',Archive = Archives[id])
@app.route('/message',methods=['POST','GET'])
def zpKLpJWhionTVIBpMmOfVRFFymwnHWoW():
    if request.method == 'GET':
        return render_template('message.html')
    else:
        type = request.form['type'][:1]
        GnhtpzUMRZloJKxoggvYzVPFZegJOBQo = request.form['msg']
        try:
            zMpdRCCXcdRMDQAYCiuCtURTmTRZwYlj = base64.b64decode(request.cookies.get('user'))
            zMpdRCCXcdRMDQAYCiuCtURTmTRZwYlj = pickle.loads(zMpdRCCXcdRMDQAYCiuCtURTmTRZwYlj)
            QfCbVmxHtTcYDksiPcqCWgrNervHQDoA = zMpdRCCXcdRMDQAYCiuCtURTmTRZwYlj["name"]
        except Exception as soxXYgIdELQdYcvNUKELZyQBSnEuiGaZ:
            print(soxXYgIdELQdYcvNUKELZyQBSnEuiGaZ)
            QfCbVmxHtTcYDksiPcqCWgrNervHQDoA = "Guest"
        if len(GnhtpzUMRZloJKxoggvYzVPFZegJOBQo)>35:
            return render_template('message.html', msg='留言太长了！', status='留言失败')
        GnhtpzUMRZloJKxoggvYzVPFZegJOBQo = GnhtpzUMRZloJKxoggvYzVPFZegJOBQo.replace(' ','')
        GnhtpzUMRZloJKxoggvYzVPFZegJOBQo = GnhtpzUMRZloJKxoggvYzVPFZegJOBQo.replace('_', '')
        lXKGklgbUoAEcAamQHRaTQumElxjTikM = fGvJjqhhlDZwxjaOwhkjDPwybGqGCuPO(type,GnhtpzUMRZloJKxoggvYzVPFZegJOBQo)
        return render_template('message.html',msg=lXKGklgbUoAEcAamQHRaTQumElxjTikM,status='%s,留言成功'%QfCbVmxHtTcYDksiPcqCWgrNervHQDoA)
def _sandbox_filter(command):
    blacklist = [
        'object',
        'exec',
        'sh',
        '__getitem__',
        '__setitem__',
        'import',
        '=',
        'open',
        'sys',
        ';',
        'os',
        'tcp',
        '`',
        '&',
        'base64',
        'flag',
        'eval'
    ]
    for forbid in blacklist:
        if forbid in command:
            return 'hack'
    return ""
@app.route('/hello',methods=['GET', 'POST'])
def SxMqGQyIdzOCUNdeTwDZZJuHTYGkQMQj():
    QfCbVmxHtTcYDksiPcqCWgrNervHQDoA = request.cookies.get('username')
    QfCbVmxHtTcYDksiPcqCWgrNervHQDoA = str(base64.b64decode(QfCbVmxHtTcYDksiPcqCWgrNervHQDoA), encoding = "utf-8")
    flag = _sandbox_filter(QfCbVmxHtTcYDksiPcqCWgrNervHQDoA)
    if flag:
        kdwpAYPhTQqfOhoGvxkJCgXzhPGSTffw = "error"
    else :
        kdwpAYPhTQqfOhoGvxkJCgXzhPGSTffw = xNBDtkLZDLeJdmLDjVGzuwsZtSakcPrb.from_string("Hello , " + QfCbVmxHtTcYDksiPcqCWgrNervHQDoA + '!').render()
    gWeZkmbNCfXlUwwbthMybQBdITCvauAC = False
    return render_template('hello.html', msg=kdwpAYPhTQqfOhoGvxkJCgXzhPGSTffw,is_value=gWeZkmbNCfXlUwwbthMybQBdITCvauAC)
@app.route('/getvdot',methods=['POST','GET'])
def IbAzRdGFLYjmgtPtMzksPoPcLlfmMcmW():
    if request.method == 'GET':
        return render_template('getvdot.html')
    else:
        vHPhdVwXzQvfkSybPzjduwOGzgnSaZPh = base64.b64decode(request.form['matrix1'])
        nSfOYIgAEjKvUPfnrnrvLevChCHltxIh = base64.b64decode(request.form['matrix2'])
        try:
            vHPhdVwXzQvfkSybPzjduwOGzgnSaZPh = numpy.loads(vHPhdVwXzQvfkSybPzjduwOGzgnSaZPh)
            nSfOYIgAEjKvUPfnrnrvLevChCHltxIh = numpy.loads(nSfOYIgAEjKvUPfnrnrvLevChCHltxIh)
        except Exception as soxXYgIdELQdYcvNUKELZyQBSnEuiGaZ:
            print(soxXYgIdELQdYcvNUKELZyQBSnEuiGaZ)
        MShnjPALwkCgUwdIIsFjYyhGvVsEgVLc = numpy.vdot(vHPhdVwXzQvfkSybPzjduwOGzgnSaZPh,nSfOYIgAEjKvUPfnrnrvLevChCHltxIh)
        print(MShnjPALwkCgUwdIIsFjYyhGvVsEgVLc)
        return render_template('getvdot.html',GnhtpzUMRZloJKxoggvYzVPFZegJOBQo=MShnjPALwkCgUwdIIsFjYyhGvVsEgVLc,status='向量点积')
def NQzCOHhQGLnkvYTdoikmOuTdFaWjmTHF(WDMsReWUjirxIhWHctkSdWwIzklwpiug, OyfWRhsWSvszaMjArDigQxyOIgJOoUlz, SebLkcLkWvHNmVcyqtZpABrmqibklCEB):
    lOHzOeKudYbieOwNWhNXqmmklcqXakZH = shelve.open(YRpxSAtoUsibvJYSNLIvYolgwUhZrDuu)
    if 'greeting_list' not in lOHzOeKudYbieOwNWhNXqmmklcqXakZH:
        RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH = []
    else:
        RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH = lOHzOeKudYbieOwNWhNXqmmklcqXakZH['greeting_list']
    RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH.insert(
        0, {'name': WDMsReWUjirxIhWHctkSdWwIzklwpiug, 'comment': OyfWRhsWSvszaMjArDigQxyOIgJOoUlz, 'create_at': SebLkcLkWvHNmVcyqtZpABrmqibklCEB})
    lOHzOeKudYbieOwNWhNXqmmklcqXakZH['greeting_list'] = RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH
    lOHzOeKudYbieOwNWhNXqmmklcqXakZH.close()
def dWRAwgaFmZlOWoeIuKvjvxRjGPLWoIKt():
    lOHzOeKudYbieOwNWhNXqmmklcqXakZH = shelve.open(YRpxSAtoUsibvJYSNLIvYolgwUhZrDuu)
    RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH = lOHzOeKudYbieOwNWhNXqmmklcqXakZH.get('greeting_list', [])
    lOHzOeKudYbieOwNWhNXqmmklcqXakZH.close()
    return RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH
@app.route('/message2')
def HAqvbEFwAEbxpPEDkTdOZFRfBWDwChcZ():
    RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH = dWRAwgaFmZlOWoeIuKvjvxRjGPLWoIKt()
    return render_template('message2.html', greeting_list=RTzPZUboZRubXyJnbXXWHhXRuLjqhWGH)
@app.route('/post', methods=['POST'])
def cnLnKgpoiGtsJxZdAqLONAYlfUbnsdEQ():
    WDMsReWUjirxIhWHctkSdWwIzklwpiug = request.form.get('name')
    OyfWRhsWSvszaMjArDigQxyOIgJOoUlz = request.form.get('comment')
    SebLkcLkWvHNmVcyqtZpABrmqibklCEB = datetime.now()
    NQzCOHhQGLnkvYTdoikmOuTdFaWjmTHF(WDMsReWUjirxIhWHctkSdWwIzklwpiug, OyfWRhsWSvszaMjArDigQxyOIgJOoUlz, SebLkcLkWvHNmVcyqtZpABrmqibklCEB)
    return redirect('/message2')
if __name__ == '__main__':
    app.run(host='0.0.0.0',port='5000',debug=True)
