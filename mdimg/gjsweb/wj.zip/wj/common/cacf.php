<?php
header('Content-Type: text/html; charset=UTF-8');
class j1nd{
	var $test = '12s1';
	function __wakeup(){
		$fp = fopen("log.php","w") ;
		fwrite($fp,$this->test);
		fclose($fp);
	}
}
function is_serialized( $data ) {
     $data = trim( $data );
     if ( 'N;' == $data )
         return true;
     if ( !preg_match( '/^([adObis]):/', $data, $badions ) )
         return false;
     switch ( $badions[1] ) {
         case 'a' :
         case 'O' :
         case 's' :
             if ( preg_match( "/^{$badions[1]}:[0-9]+:.*[;}]\$/s", $data ) )
                 return true;
             break;
         case 'b' :
         case 'i' :
         case 'd' :
             if ( preg_match( "/^{$badions[1]}:[0-9.E-]+;\$/", $data ) )
                 return true;
             break;
     }
     return false;
 }


if(isset($_POST['name'])){
	$post_data=$_POST['name'];
	if(is_serialized($post_data)){
	echo $post_data;
	unserialize($post_data);
}
else{
	echo "你好 ".$post_data.",你的简历分数为 ".mt_rand(60,100)." 分";
}

}
else{
	echo("请输入你的名字");
}

?>
<html>
<form action="#" method="post">
<input type="text" name="name">
<input type="submit" name="submit" value="提交">
</form>
</html>