<?php

define("DBHOST","localhost");
define('DBUSER','root');
define('DBPASS','root');
define('DBNAME','web1');
define('ROOTDRI',__DIR__."/../");

require(ROOTDRI.'/org/smarty/Smarty.class.php');

session_start();

?>
