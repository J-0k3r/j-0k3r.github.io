<?php
    class File1{

        private $typelist;
        private $allowexten;
        private $path;

        function __construct(){
            
            if (!isset($_SESSION['username'])){
                exit("not login");
            }
            $this->path='/tmp/uploads/';
            if(!file_exists($this->path)){
                mkdir($this->path,0777,true);
            }
            $this->allow=array("zip");
        }

        function save(){
            include_once __DIR__."/zip.php";
            $id=$_SESSION['id'];
            if(intval($id) !== 1 ){
                exit("you are not admin");
            }
            $upfile=$_FILES['pic'];
            $fileinfo=pathinfo($upfile["name"]);
            
            if(!in_array(strtolower($fileinfo["extension"]),$this->allow)){
                exit('the file suffix is not allowed');
            }
            $filepath = $this->path.$id."_".$fileinfo['filename'].".".strtolower($fileinfo["extension"]);
            if (file_exists($filepath)){
                exit("file already exists");
            }
            if(move_uploaded_file($upfile['tmp_name'],  $filepath)){
                $z = new Unzip();
                $z->unzip($filepath, $this->path);
                return True;
            }else{
                return False;
            }
        }
    }
?>