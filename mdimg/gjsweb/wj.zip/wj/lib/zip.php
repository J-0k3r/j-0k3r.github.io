<?php
    class Unzip{
        public function __construct(){
            header("content-type:text/html;charset=utf8");
        }
        public function unzip($src_file, $dest_dir){
            $unzip = "unzip -o $src_file -d $dest_dir";
            exec($unzip);
        }
    }

?>