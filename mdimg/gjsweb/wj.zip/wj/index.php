<?php
include "./common/function.php";
include "./include/config.php";
include "./lib/base.php";


ini_set("display_errors","On"); //开启报错

$c=isset($_GET['c'])?$_GET['c']:'User';
$a=isset($_GET['a'])?$_GET['a']:'Index';

$obj=run_c($c);
run_a($obj,$a);
?>
